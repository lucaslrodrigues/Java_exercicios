/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lucas.atividade.data.nascimento;

/**
 *
 * @author lukas
 */
public class Teste {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa("2003-01-09");
        System.out.println(pessoa.calcularIdade());
    }
}
